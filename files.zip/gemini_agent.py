"""
Gemini AI Agent for EcoRoute Optimizer
Free alternative to Claude using Google's Gemini
"""

import json
import sys
from pathlib import Path
from typing import List, Dict, Optional

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

try:
    import google.generativeai as genai
    GEMINI_AVAILABLE = True
except ImportError:
    GEMINI_AVAILABLE = False
    print("Warning: google-generativeai package not installed. Install with: pip install google-generativeai")

from config.settings import GEMINI_API_KEY
from src.routing.route_finder import route_finder
from src.routing.optimizer import optimizer
from src.agent.prompts import SYSTEM_PROMPT


class GeminiRouteAgent:
    """AI Agent using Google Gemini (Free tier)"""
    
    def __init__(self, api_key: str = None):
        if not GEMINI_AVAILABLE:
            raise ImportError("google-generativeai package required. Install with: pip install google-generativeai")
        
        self.api_key = api_key or GEMINI_API_KEY
        if not self.api_key or self.api_key == "your_gemini_key_here":
            raise ValueError("Gemini API key not configured. Set GEMINI_API_KEY in .env")
        
        # Configure Gemini
        genai.configure(api_key=self.api_key)
        
        # Use Gemini 1.5 Flash (free, fast, good for tool calling)
        self.model = genai.GenerativeModel(
            model_name='gemini-1.5-flash',
            system_instruction=SYSTEM_PROMPT,
            tools=[self.find_routes_tool, self.get_recommendation_tool]
        )
        
        self.chat = self.model.start_chat(enable_automatic_function_calling=True)
    
    def find_routes_tool(self, origin: str, destination: str, 
                        weight_lbs: float = 1000,
                        deadline_hours: Optional[float] = None) -> Dict:
        """
        Tool function: Generate route options
        
        Args:
            origin: Origin city name
            destination: Destination city name
            weight_lbs: Shipment weight in pounds (default 1000)
            deadline_hours: Optional delivery deadline in hours
        
        Returns:
            Dictionary with routes and metadata
        """
        print(f"\n[Tool Call: find_routes]")
        print(f"  Origin: {origin}")
        print(f"  Destination: {destination}")
        print(f"  Weight: {weight_lbs} lbs")
        
        routes = route_finder.generate_all_routes(
            origin=origin,
            destination=destination,
            weight_lbs=weight_lbs,
            deadline_hours=deadline_hours
        )
        
        return {
            "success": True,
            "routes": routes,
            "count": len(routes),
            "origin": origin,
            "destination": destination
        }
    
    def get_recommendation_tool(self, routes: List[Dict], 
                               preference: str = "balanced") -> Dict:
        """
        Tool function: Get route recommendation
        
        Args:
            routes: List of route options
            preference: User preference (cost/time/carbon/balanced)
        
        Returns:
            Recommendation with reasoning
        """
        print(f"\n[Tool Call: get_recommendation]")
        print(f"  Preference: {preference}")
        
        rec = optimizer.generate_recommendation(routes, preference)
        return rec
    
    def chat_message(self, user_message: str) -> str:
        """
        Send a message and get response (with automatic tool calling)
        
        Args:
            user_message: User's question/request
        
        Returns:
            Gemini's response text
        """
        try:
            # Send message (Gemini automatically calls tools if needed)
            response = self.chat.send_message(user_message)
            
            # Extract text response
            return response.text
            
        except Exception as e:
            return f"Error: {str(e)}\n\nPlease try rephrasing your question."
    
    def reset_conversation(self):
        """Clear conversation history"""
        self.chat = self.model.start_chat(enable_automatic_function_calling=True)


# Test function
def test_gemini_agent():
    """Test the Gemini AI agent"""
    
    if not GEMINI_AVAILABLE:
        print("google-generativeai package not installed. Skipping test.")
        print("Install with: pip install google-generativeai")
        return
    
    print("\nTESTING GEMINI AI AGENT")
    print("=" * 70)
    
    try:
        agent = GeminiRouteAgent()
    except ValueError as e:
        print(f"\nERROR: {e}")
        print("\nPlease set your Gemini API key in .env file:")
        print("GEMINI_API_KEY=AIza-your-key-here")
        print("\nGet a free key at: https://aistudio.google.com/app/apikey")
        return
    except Exception as e:
        print(f"\nERROR: {e}")
        return
    
    # Test query
    print("\nUser Query:")
    print("-" * 70)
    query = "I need to ship 1500 lbs from San Francisco to Chicago. What are my options?"
    print(query)
    
    print("\n\nGemini's Response:")
    print("-" * 70)
    
    response = agent.chat_message(query)
    print(response)
    
    print("\n" + "=" * 70)
    print("GEMINI AGENT TEST COMPLETE\n")


if __name__ == "__main__":
    test_gemini_agent()
